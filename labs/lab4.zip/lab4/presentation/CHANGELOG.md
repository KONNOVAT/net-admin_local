## [1.0.4](https://github.com/yamadharma/academic-presentation-markdown-template/compare/v1.0.3...v1.0.4) (2024-08-31)


### Bug Fixes

* **presentation:** fix compilation ([7e754ff](https://github.com/yamadharma/academic-presentation-markdown-template/commit/7e754ff9ac64a589504f47b12973255a913861c6))



## [1.0.3](https://github.com/yamadharma/academic-presentation-markdown-template/compare/v1.0.2...v1.0.3) (2023-11-05)


### Features

* **presentation:** switch to xelatex ([198b73c](https://github.com/yamadharma/academic-presentation-markdown-template/commit/198b73c7c27df96f1b95a8733f1c3b399312fee5))



## [1.0.2](https://github.com/yamadharma/academic-presentation-markdown-template/compare/v1.0.1...v1.0.2) (2023-02-07)


### Bug Fixes

* **filters:** disable pandoc-crossref ([0c33e5d](https://github.com/yamadharma/academic-presentation-markdown-template/commit/0c33e5d18af2a4f96d246d8962e52ea292721b11))



## [1.0.1](https://github.com/yamadharma/academic-presentation-markdown-template/compare/v1.0.0...v1.0.1) (2022-08-28)


### Features

* **make:** add html target (reveal.js) ([9bc9cb7](https://github.com/yamadharma/academic-presentation-markdown-template/commit/9bc9cb7cbdd8368245f64b70889a40bf0d8c73ac))
* **text:** add babel support ([a213f49](https://github.com/yamadharma/academic-presentation-markdown-template/commit/a213f491f2a55d94281832d442c9a89723db4380))
* **text:** add structure of presentation ([1f16985](https://github.com/yamadharma/academic-presentation-markdown-template/commit/1f169857cd7394c25d2b263ed1048b66f286c1cc))
* **text:** add structured description ([873645c](https://github.com/yamadharma/academic-presentation-markdown-template/commit/873645c7d454cb319e28048be5e6e8832d4ca173))



# [1.0.0](https://github.com/yamadharma/academic-presentation-markdown-template/compare/v0.0.1...v1.0.0) (2022-04-14)


### Features

* **main:** change license ([1ca0cb3](https://github.com/yamadharma/academic-presentation-markdown-template/commit/1ca0cb3275f247880e449c24fb5d9cc09e626b69))
* **main:** rename directories ([c7a1424](https://github.com/yamadharma/academic-presentation-markdown-template/commit/c7a1424f7bbee79fbbdc3327423eae00ae0e97ba))




